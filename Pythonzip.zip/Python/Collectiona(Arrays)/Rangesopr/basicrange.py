print(range(5))

for i in range(0,10,2) :
    print(i)

lis = list(range(1,11,2))
print(lis)