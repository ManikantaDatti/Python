'''                             Lists
1. Listas are order collections. immutable
2. we can add, deletee , change
3. Remaning as same as tuple
4. contains duplicates also'''

lis = [45,567,4563,345]
print(lis)

#check operator for existed or not
print(567 in lis)