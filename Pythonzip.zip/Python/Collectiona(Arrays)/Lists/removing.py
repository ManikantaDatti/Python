''''To remove elements from list there are sevreal methods
1.remove(item) : for removing specific element
2. pop() :  removes last element
3. pop(index) : removes specific index element
4. clear() remove all elements
5. del lis[index] : removes specifc index element from list'''