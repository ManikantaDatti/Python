lis = [5,6,54,54,54,54,54,4,43,432,2,6]

print(lis[:])
print(lis[0:])
print(lis[:6])
print(lis[: :-1])
print(lis[::2])
print(lis[-1:])
print(lis[:])
print(lis[:])
print(lis[-1:-4 :-2])
print(lis[-4:-1])