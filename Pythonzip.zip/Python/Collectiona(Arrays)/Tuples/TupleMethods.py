#since tuple is immutable so no methods to work onit
tup = (1,4,6,3,5,3,4,3,3,5)
print(tup.count(3))
print(tup.index(3))
print(min(tup))
print(max(tup))
print(sorted(tup))