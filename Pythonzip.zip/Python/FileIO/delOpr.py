import os 
os.remove('ye.txt')