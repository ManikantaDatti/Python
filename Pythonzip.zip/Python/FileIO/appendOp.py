f = open('hi.txt','a')
f.write('hiiiiiiiiiiiiiiiiiii')