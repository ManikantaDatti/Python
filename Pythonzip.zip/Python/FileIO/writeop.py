f = open('hi.txt', 'w')
f.write('Datti Manikanta')
f.close()
exit