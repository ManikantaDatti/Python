#f = open('Bye.txt','w')
f = open('Bye.txt','x')