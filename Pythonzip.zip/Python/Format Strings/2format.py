name = "manu"
age = 22
sal = 3456.3456

print("name is {} and age is {} and sal is {}".format(name,age,sal))
print("name is {0} and age is {1} and sal is {2}".format(name,age,sal))
print("name is {name} and age is {age} and sal is {sal}".format(name = 'm',age=22,sal=0))
print(format(sal,'.2f'))
