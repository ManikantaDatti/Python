name = "manu"
age = 22
sal = 3456.3456

print(f"name is {name} and age is {age} and sal is {sal}")