import pandas as pd

lis = [3,4,6,5,6]

pd_lis = pd.Series(lis)

print(pd_lis)