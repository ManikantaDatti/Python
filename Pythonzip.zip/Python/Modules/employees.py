import Emp1
print(Emp1.Emp1.name)