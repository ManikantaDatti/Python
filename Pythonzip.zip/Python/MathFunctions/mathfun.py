import math
print(math.pow(4,4))
math.floor()
math.ciel()
math.abs()
math.pi
math.sqrt()