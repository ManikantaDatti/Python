x = 10
try :
    print(x)
except :
    print('variable not defined')
else :
    print('no error found')